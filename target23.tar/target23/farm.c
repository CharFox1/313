/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_456(unsigned x)
{
    return x + 3281031240U;
}

unsigned addval_408(unsigned x)
{
    return x + 3281016915U;
}

unsigned addval_198(unsigned x)
{
    return x + 3284633928U;
}

void setval_228(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_109(unsigned x)
{
    return x + 2425378962U;
}

unsigned addval_206(unsigned x)
{
    return x + 1235796952U;
}

void setval_353(unsigned *p)
{
    *p = 3351742792U;
}

void setval_452(unsigned *p)
{
    *p = 2462550344U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_231()
{
    return 3353381192U;
}

unsigned getval_144()
{
    return 3767093334U;
}

unsigned addval_453(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_354(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_331()
{
    return 717477515U;
}

void setval_359(unsigned *p)
{
    *p = 3767101526U;
}

unsigned getval_278()
{
    return 3229931149U;
}

void setval_129(unsigned *p)
{
    *p = 3380923033U;
}

unsigned addval_118(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_441()
{
    return 3222847881U;
}

unsigned addval_284(unsigned x)
{
    return x + 3281043849U;
}

void setval_322(unsigned *p)
{
    *p = 3281111689U;
}

void setval_381(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_419()
{
    return 3523791497U;
}

unsigned addval_277(unsigned x)
{
    return x + 3674789513U;
}

unsigned getval_470()
{
    return 3247491721U;
}

unsigned getval_434()
{
    return 3227566473U;
}

void setval_252(unsigned *p)
{
    *p = 3380923016U;
}

void setval_135(unsigned *p)
{
    *p = 3230974345U;
}

void setval_183(unsigned *p)
{
    *p = 3675832713U;
}

unsigned getval_179()
{
    return 3224950281U;
}

unsigned addval_321(unsigned x)
{
    return x + 3385115017U;
}

unsigned getval_390()
{
    return 3375945369U;
}

unsigned addval_391(unsigned x)
{
    return x + 3767093442U;
}

void setval_332(unsigned *p)
{
    *p = 3281049225U;
}

unsigned addval_137(unsigned x)
{
    return x + 2429193695U;
}

unsigned addval_314(unsigned x)
{
    return x + 3525886345U;
}

void setval_142(unsigned *p)
{
    *p = 3281046153U;
}

unsigned getval_298()
{
    return 3523789193U;
}

void setval_446(unsigned *p)
{
    *p = 3526940301U;
}

unsigned getval_445()
{
    return 2425670281U;
}

unsigned addval_273(unsigned x)
{
    return x + 3222853257U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
